import base64
import io
import os
import logging
import numpy as np
import cv2
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import ensure_csrf_cookie
from PIL import Image
from django.core.mail import send_mail
from django.conf import settings

logger = logging.getLogger(__name__)

@ensure_csrf_cookie
def index(request):
    return render(request, 'index.html')

def apply_filter(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'}, status=400)
    
    try:
        image_data = request.POST.get('image')
        filter_name = request.POST.get('filter')
        
        if not image_data or not filter_name:
            return JsonResponse({'error': 'Missing image data or filter name'}, status=400)
        
        # Remove the data URL prefix if present
        if 'base64,' in image_data:
            image_data = image_data.split('base64,')[1]
        
        # Decode the base64 image
        image_bytes = base64.b64decode(image_data)
        nparr = np.frombuffer(image_bytes, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if image is None:
            return JsonResponse({'error': 'Failed to decode image'}, status=400)

        # Apply the selected filter
        filtered_image = None
        
        try:
            if filter_name == 'blur':
                from .filters.blur import apply_blur
                filtered_image = apply_blur(image)
            elif filter_name == 'crop':
                from .filters.crop import apply_crop
                filtered_image = apply_crop(image)
            elif filter_name == 'fuzz':
                from .filters.fuzz import apply_fuzz
                filtered_image = apply_fuzz(image)
            elif filter_name == 'grayscale':
                from .filters.grayscale import apply_grayscale
                filtered_image = apply_grayscale(image)
            elif filter_name == 'hsv':
                from .filters.hsv import apply_hsv
                filtered_image = apply_hsv(image)
            elif filter_name == 'posterize':
                from .filters.posterize import apply_posterize
                filtered_image = apply_posterize(image)
            elif filter_name == 'rotate':
                from .filters.rotate import apply_rotation
                filtered_image = apply_rotation(image)
            elif filter_name == 'smoothen':
                from .filters.smoothen import apply_smoothing
                filtered_image = apply_smoothing(image)
            else:
                return JsonResponse({'error': f'Unknown filter: {filter_name}'}, status=400)
        except ImportError as e:
            logger.error(f"Failed to import filter module: {str(e)}")
            return JsonResponse({'error': f'Filter {filter_name} is not available'}, status=500)
        except Exception as e:
            logger.error(f"Error applying filter {filter_name}: {str(e)}")
            return JsonResponse({'error': f'Failed to apply filter: {str(e)}'}, status=500)
        
        if filtered_image is None:
            return JsonResponse({'error': 'Filter application failed'}, status=500)
        
        # Encode the filtered image back to base64
        _, buffer = cv2.imencode('.jpg', filtered_image)
        filtered_image_data = base64.b64encode(buffer).decode('utf-8')
        
        return JsonResponse({
            'image': f'data:image/jpeg;base64,{filtered_image_data}'
        })
    
    except Exception as e:
        logger.error(f"Unexpected error in apply_filter: {str(e)}")
        return JsonResponse({'error': str(e)}, status=500)

def send_email(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'}, status=400)
    
    try:
        email = request.POST.get('email')
        image_data = request.POST.get('image')
        
        if not email or not image_data:
            return JsonResponse({'error': 'Missing email or image data'}, status=400)
        
        # Remove the data URL prefix if present
        if 'base64,' in image_data:
            image_data = image_data.split('base64,')[1]
        
        # Decode the base64 image
        image_bytes = base64.b64decode(image_data)
        
        # Create a temporary file
        temp_image_path = 'temp_image.jpg'
        with open(temp_image_path, 'wb') as f:
            f.write(image_bytes)
        
        # Send the email
        with open(temp_image_path, 'rb') as image_file:
            send_mail(
                'Your Photo Booth Image',
                'Here is your captured image from the photo booth.',
                settings.EMAIL_HOST_USER,
                [email],
                fail_silently=False,
                attachments=[('photo.jpg', image_file.read(), 'image/jpeg')]
            )
        return JsonResponse({'status': 'Email sent successfully'})
    
    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return JsonResponse({'error': str(e)}, status=500)
    finally:
        # Clean up the temporary file
        if os.path.exists(temp_image_path):
            os.remove(temp_image_path)