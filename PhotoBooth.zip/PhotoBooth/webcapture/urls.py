from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('apply_filter/', views.apply_filter, name='apply_filter'),
    path('send_email/', views.send_email, name='send_email'),
]

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),
    path('apply_filter/', views.apply_filter, name='apply_filter'),
    path('send_email/', views.send_email, name='send_email'),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])