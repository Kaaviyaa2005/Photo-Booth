import cv2

def apply_smoothing(image):
    return cv2.bilateralFilter(image, 9, 75, 75)