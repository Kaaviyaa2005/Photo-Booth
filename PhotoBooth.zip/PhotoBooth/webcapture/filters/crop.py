import cv2
import numpy as np

def apply_crop(image):
    height, width = image.shape[:2]
    # Crop 10% from each side
    crop_percent = 0.1
    x = int(width * crop_percent)
    y = int(height * crop_percent)
    w = int(width * (1 - 2 * crop_percent))
    h = int(height * (1 - 2 * crop_percent))
    return image[y:y+h, x:x+w]