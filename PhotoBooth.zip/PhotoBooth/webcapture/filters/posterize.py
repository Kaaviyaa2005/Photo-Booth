import cv2
import numpy as np

def create_lut(n):
    # Create a lookup table for posterization
    lut = np.zeros(256, dtype=np.uint8)
    for i in range(256):
        lut[i] = int(n * i / 255) * (255 // (n - 1))
    return lut

def apply_posterize(image, n=5):
    # Convert BGR to RGB
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # Apply median blur to reduce noise
    blurred = cv2.medianBlur(image_rgb, 5)
    
    # Create lookup table
    lut = create_lut(n)
    
    # Apply posterization
    posterized_image = np.zeros_like(image_rgb)
    for i in range(3):
        posterized_image[:, :, i] = cv2.LUT(blurred[:, :, i], lut)
    
    # Convert back to BGR for OpenCV
    return cv2.cvtColor(posterized_image, cv2.COLOR_RGB2BGR)

