"""
WSGI config for PhotoBooth project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/5.1/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'PhotoBooth.settings')

application = get_wsgi_application()

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # ... your other url patterns ...
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])
