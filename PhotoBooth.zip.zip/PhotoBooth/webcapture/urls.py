from django.urls import path
from .views import index, apply_filter, send_email

urlpatterns = [
    path('', index, name='index'),
    path('apply_filter/', apply_filter, name='apply_filter'),
    path('send_email/', send_email, name='send_email'),
]
