from django.apps import AppConfig


class WebcaptureConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'webcapture'
