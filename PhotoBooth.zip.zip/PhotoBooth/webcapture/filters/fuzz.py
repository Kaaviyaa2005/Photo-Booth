import cv2

def apply_fuzz(image, kernel_size=5):
    return cv2.medianBlur(image, kernel_size)
