# rotate.py
import cv2
def apply_rotation(image):
    return cv2.rotate(image, cv2.ROTATE_180)