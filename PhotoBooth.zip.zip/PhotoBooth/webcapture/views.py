import base64
import io
import os
import logging
import numpy as np
import cv2
from django.shortcuts import render
from django.http import JsonResponse
from PIL import Image
from django.core.mail import send_mail
from django.conf import settings
from .filters.grayscale import apply_grayscale
from .filters.blur import apply_blur
from .filters.posterize import apply_posterize
from .filters.rotate import apply_rotation
from .filters.smoothen import apply_smoothing
from .filters.crop import apply_crop
from .filters.fuzz import apply_fuzz
from .filters.hsv import apply_hsv

logger = logging.getLogger(__name__)

def index(request):
    return render(request, 'index.html')

def apply_filter(request):
    if request.method == 'POST':
        image_data = request.POST.get('image')
        filter_name = request.POST.get('filter')
        is_active = request.POST.get('is_active') == 'true'

        logger.debug(f"Filter Name: {filter_name}, Is Active: {is_active}")

        # Decode the base64 image
        image_data = image_data.split(',')[1]
        image = base64.b64decode(image_data)
        np_image = np.frombuffer(image, np.uint8)
        image = cv2.imdecode(np_image, cv2.IMREAD_COLOR)

        # Apply the selected filter if it is active
        if is_active:
            logger.debug("Applying filter...")
            if filter_name == 'blur':
                result_image = apply_blur(image)
            elif filter_name == 'crop':
                result_image = apply_crop(image)
            elif filter_name == 'fuzz':
                result_image = apply_fuzz(image)
            elif filter_name == 'grayscale':
                result_image = apply_grayscale(image)
            elif filter_name == 'hsv':
                result_image = apply_hsv(image)
            elif filter_name == 'posterize':
                result_image = apply_posterize(image)
            elif filter_name == 'rotate':
                result_image = apply_rotation(image)
            elif filter_name == 'smoothen':
                result_image = apply_smoothing(image)
            else:
                logger.warning(f"No filter found for: {filter_name}")
                result_image = image  # No filter, return original
        else:
            logger.debug("No filter applied.")
            result_image = image  # No filter applied

        # Encode the result image back to base64
        _, buffer = cv2.imencode('.jpg', result_image)
        result_image_data = base64.b64encode(buffer).decode('utf-8')
        result_image_url = f"data:image/jpeg;base64,{result_image_data}"

        logger.debug("Filter applied successfully.")
        return JsonResponse({'image': result_image_url})

    logger.error("Invalid request method.")
    return JsonResponse({'error': 'Invalid request'}, status=400)

def send_email(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        image_data = request.POST.get('image')

        # Decode the base64 image
        image_data = image_data.split(',')[1]
        image_bytes = base64.b64decode(image_data)

        # Create a PIL Image
        image = Image.open(io.BytesIO(image_bytes))

        # Save image to a temporary file
        temp_image_path = 'temp_image.jpg'
        image.save(temp_image_path)

        # Send the email with the image attached
        subject = 'Your Edited Image'
        message = 'Please find your edited image attached.'
        email_from = settings.EMAIL_HOST_USER

        try:
            # Attach the image
            with open(temp_image_path, 'rb') as image_file:
                send_mail(
                    subject,
                    message,
                    email_from,
                    [email],
                    fail_silently=False,
                    html_message='<p>Attached is your edited image.</p>',
                    attachments=[(temp_image_path, image_file.read(), 'image/jpeg')]
                )
            # Clean up: Remove temporary image file
            os.remove(temp_image_path)
            return JsonResponse({'status': 'Email sent successfully'})
        except Exception as e:
            logger.error(f"Error sending email: {str(e)}")
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'error': 'Invalid request'}, status=400)
